<?php 
include 'components/connection.php';
session_start();

// Initialize variables
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : '';
$warning_msg = []; // Initialize warning messages array

// Handle logout request
if(isset($_POST['logout'])) {
    session_destroy();
    header("location: login.php");
    exit;
}

// Handle place order request
if(isset($_POST['place_order'])) {
    // Sanitize input data
    $name = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
    $number = filter_var($_POST['number'], FILTER_SANITIZE_STRING);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $flat = filter_var($_POST['flat'], FILTER_SANITIZE_STRING);
    $street = filter_var($_POST['street'], FILTER_SANITIZE_STRING);
    $city = filter_var($_POST['city'], FILTER_SANITIZE_STRING);
    $country = filter_var($_POST['country'], FILTER_SANITIZE_STRING);
    $pincode = filter_var($_POST['pincode'], FILTER_SANITIZE_STRING);
    $address = "$flat, $street, $city, $country, $pincode";
    $address_type = filter_var($_POST['address_type'], FILTER_SANITIZE_STRING);
    $method = filter_var($_POST['method'], FILTER_SANITIZE_STRING);

    // Check if cart has items
    $verify_cart = $conn->prepare("SELECT * FROM cart WHERE user_id = ?");
    $verify_cart->execute([$user_id]);

    if ($verify_cart->rowCount() > 0) {
        // Start transaction for inserting orders
        try {
            $conn->beginTransaction();

            while ($fetch_cart = $verify_cart->fetch(PDO::FETCH_ASSOC)) {
                // Fetch product details
                $select_product = $conn->prepare("SELECT * FROM products WHERE id = ?");
                $select_product->execute([$fetch_cart['product_id']]);
                $fetch_product = $select_product->fetch(PDO::FETCH_ASSOC);

                // Insert order details
                $insert_order = $conn->prepare("INSERT INTO orders (id, user_id, name, number, email, address, address_type, method, product_id, price, qty) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $insert_order->execute([unique_id(), $user_id, $name, $number, $email, $address, $address_type, $method, $fetch_cart['product_id'], $fetch_product['price'], $fetch_cart['qty']]);
            }

            // Commit transaction
            $conn->commit();

            // Clear cart after successful order placement
            $delete_cart = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
            $delete_cart->execute([$user_id]);

            // Redirect to order confirmation page
            header('location: order.php');
            exit;
        } catch (PDOException $e) {
            // Rollback transaction on error
            $conn->rollback();
            $warning_msg[] = 'Something went wrong with placing your order.';
        }
    } else {
        $warning_msg[] = 'Your cart is empty. Add items to your cart before placing an order.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Green Coffee - Checkout Page</title>
    <style>
        <?php include 'style.css'; ?>
    </style>
</head>
<body>
    <?php include 'components/header.php'; ?>
    <div class="main">
        <div class="banner">
            <h1>Checkout Summary</h1>
        </div>      
        <div class="title2">
            <a href="home.php">Home</a><span>/ Checkout Summary</span>
        </div>
        <section class="checkout">
            <div class="title">
                <img src="img/download.png" class="logo" alt="Green Coffee Logo">
                <h1>Checkout Summary</h1>
                <p></p>
            </div>
            <div class="row">
                <form method="post">
                    <h3>Billing Details</h3>
                    <div class="flex">
                        <div class="box">
                            <div class="input-field">
                                <p>Your Name <span>*</span></p>
                                <input type="text" name="name" required maxlength="50" placeholder="Enter your name" class="input">
                            </div>
                            <div class="input-field">
                                <p>Your Number <span>*</span></p>
                                <input type="text" name="number" required maxlength="10" placeholder="Enter your number" class="input">
                            </div>
                            <div class="input-field">
                                <p>Your Email <span>*</span></p>
                                <input type="email" name="email" required maxlength="50" placeholder="Enter your email" class="input">
                            </div>
                            <div class="input-field">
                                <p>Payment Method <span>*</span></p>
                                <select name="method" class="input">
                                    <option value="cash on delivery">Cash on Delivery</option>
                                    <option value="credit or debit card">Credit or Debit Card</option>
                                    <option value="net banking">Net Banking</option>
                                    <option value="UPI or RuPay">UPI or RuPay</option>
                                    <option value="paytm">Paytm</option>
                                </select>
                            </div>
                            <div class="input-field">
                                <p>Address Type <span>*</span></p>
                                <select name="address_type" class="input">
                                    <option value="home">Home</option>
                                    <option value="office">Office</option>
                                </select>
                            </div>
                        </div>
                        <div class="box">
                            <div class="input-field">
                                <p>Address Line 01 <span>*</span></p>
                                <input type="text" name="flat" required maxlength="50" placeholder="e.g. Flat and building number" class="input">
                            </div>
                            <div class="input-field">
                                <p>Address Line 02 <span>*</span></p>
                                <input type="text" name="street" required maxlength="50" placeholder="e.g. Street number" class="input">
                            </div>
                            <div class="input-field">
                                <p>City Name <span>*</span></p>
                                <input type="text" name="city" required maxlength="50" placeholder="Enter your city name" class="input">
                            </div>
                            <div class="input-field">
                                <p>Country Name <span>*</span></p>
                                <input type="text" name="country" required maxlength="50" placeholder="Enter your country name" class="input">
                            </div>
                            <div class="input-field">
                                <p>Pincode <span>*</span></p>
                                <input type="text" name="pincode" required maxlength="6" placeholder="110022" class="input">
                            </div>
                        </div>
                    </div>
                    <button type="submit" name="place_order" class="btn">Place Order</button>
                </form>
                <div class="summary">
                    <h3>My Bag</h3>
                    <div class="box-container">
                        <?php
                        $grand_total = 0;

                        // Fetch products from cart
                        $select_cart = $conn->prepare("SELECT c.qty, p.* FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id = ?");
                        $select_cart->execute([$user_id]);

                        if ($select_cart->rowCount() > 0) {
                            while ($fetch_cart = $select_cart->fetch(PDO::FETCH_ASSOC)) {
                                $sub_total = $fetch_cart['price'] * $fetch_cart['qty'];
                                $grand_total += $sub_total;
                                ?>
                                <div class="flex">
                                    <img src="image/<?=$fetch_cart['image']; ?>" class="image">
                                    <div>
                                        <h3 class="name"><?=$fetch_cart['name']; ?></h3>
                                        <p class="price"><?=$fetch_cart['price']; ?> X <?=$fetch_cart['qty']; ?></p>
                                    </div>
                                </div>
                                <?php
                            }
                        } else {
                            echo '<p class="empty">Your cart is empty</p>';
                        } 
                        ?>
                    </div>
                    <div class="grand-total"><span>Total Amount Payable: </span>$<?=$grand_total ?>/-</div>
                </div>
            </div>
        </section>
        <?php include 'components/footer.php'; ?>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
    <script src="script.js"></script>
    <?php include 'components/alert.php'; ?>
</body>
</html>
