<?php 
include 'components/connection.php';
session_start();
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
} else {
    $user_id = '';
}
if(isset($_POST['logout'])) {
    session_destroy();
    header("location: login.php");
    exit;
}
// adding products in wishlist
if(isset($_POST['add_to_wishlist'])) {
    $id = unique_id();
    $product_id = $_POST['product_id'];

    $varify_wishlist = $conn->prepare("SELECT * FROM wishlist WHERE user_id = ? AND product_id = ?");
    $varify_wishlist->execute([$user_id, $product_id]);

    $cart_num = $conn->prepare("SELECT * FROM cart WHERE user_id = ? AND product_id = ?");
    $cart_num->execute([$user_id, $product_id]);
    
    if($varify_wishlist->rowCount() > 0){
        $warning_msg[] = 'Product already exists in your wishlist';
    } else if ($cart_num->rowCount() > 0){
        $warning_msg[] = 'Product already exists in your cart';
    } else {
        $select_price = $conn->prepare("SELECT * FROM products WHERE id = ? LIMIT 1");
        $select_price->execute([$product_id]);
        $fetch_price = $select_price->fetch(PDO::FETCH_ASSOC);

        $insert_wishlist = $conn->prepare("INSERT INTO wishlist (id, user_id, product_id, price) VALUES (?, ?, ?, ?)");
        $insert_wishlist->execute([$id, $user_id, $product_id, $fetch_price['price']]);
        $success_msg[] = 'Product added to wishlist successfully';
    }
}
// adding products in cart
if(isset($_POST['add_to_cart'])) {
    $id = unique_id();
    $product_id = $_POST['product_id'];

    $qty = $_POST['qty'];
    $qty = filter_var($qty, FILTER_SANITIZE_STRING);

    $varify_cart = $conn->prepare("SELECT * FROM cart WHERE user_id = ? AND product_id = ?");
    $varify_cart->execute([$user_id, $product_id]);

    $max_cart_items = $conn->prepare("SELECT * FROM cart WHERE user_id = ?");
    $max_cart_items->execute([$user_id]);

    if($varify_cart->rowCount() > 0){
        $warning_msg[] = 'Product already exists in your cart';
    } else if ($max_cart_items->rowCount() > 10){
        $warning_msg[] = 'Cart is full';
    } else {
        $select_price = $conn->prepare("SELECT * FROM products WHERE id = ? LIMIT 1");
        $select_price->execute([$product_id]);
        $fetch_price = $select_price->fetch(PDO::FETCH_ASSOC);

        $insert_cart = $conn->prepare("INSERT INTO cart (id, user_id, product_id, price, qty) VALUES (?, ?, ?, ?, ?)");
        $insert_cart->execute([$id, $user_id, $product_id, $fetch_price['price'], $qty]);
        $success_msg[] = 'Product added to cart successfully';
    }
}
?>
<style type="text/css">
    <?php include 'style.css'; ?>
</style>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Green Coffee - Order Page</title>
</head>
<body>
    <?php include 'components/header.php'; ?>
    <div class="main">
        <div class="banner">
            <h1>My Orders</h1>
        </div>      
        <div class="title2">
            <a href="home.php">Home</a><span>/ Order</span>
        </div>
        <section class="order">
            <div class="box-container">
               <div class="title">
                <img src="img/download.png" class="logo">
                <h1>My Orders</h1>
                <p>Your order has been placed, Thankyou for ordering</p>
               </div>
               <div class="box-container">
                <?php
                $select_orders = $conn->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY date DESC");
                $select_orders->execute([$user_id]);
                if ($select_orders->rowCount()>0) {
                    while($fetch_order = $select_orders->fetch(PDO::FETCH_ASSOC)){
                        $select_product = $conn->prepare("SELECT * FROM products WHERE id=?");
                        $select_product->execute([$fetch_order['product_id']]);
                        if ($select_product->rowCount()>0) {
                            while($fetch_product = $select_product->fetch(PDO::FETCH_ASSOC)){
                ?>
                <div class="box" <?php if($fetch_order['status']=='canceled'){echo 'style="border:2px solid red;"';}?>>
                    <a href="view_order.php?get_id=<?=$fetch_order['id']; ?>">
                    <p class="date"><i class="bi bi-calendar-fill"></i> <span><?=$fetch_order['date']; ?></span></p>
                    <img src="image/<?=$fetch_product['image']; ?>" class="image">
                    <div class="row">
                        <h3 class="name"><?=$fetch_product['name']; ?></h3>
                        <p class="price">Price: <?=$fetch_order['price']; ?> x <?=$fetch_order['qty']; ?></p>
                        <p class="status" style="color:<?php 
                        if ($fetch_order['status'] == 'delivered') {
                            echo 'green';
                        } elseif ($fetch_order['status'] == 'canceled') {
                            echo 'red';
                        } else {
                            echo 'orange';
                        }
                        ?>"></p>
                    </div>
                    </a>
                </div>
                <?php
                            }
                        }
                    }
                } else {
                   echo '<p class="empty">No orders have been placed yet!</p>' ;
                }
                ?>
               </div>
            </div>
        </section>
        <?php include 'components/footer.php'; ?>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
    <script src="script.js"></script>
    <?php include 'components/alert.php'; ?>
</body>
</html>
